# Indian Logistics Cost Prediction & Fleet Operations Intelligence

[![Python 3.11](https://img.shields.io/badge/Python-3.11-3776AB.svg?logo=python&logoColor=white)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Streamlit](https://img.shields.io/badge/Streamlit-1.40+-FF4B4B.svg?logo=streamlit&logoColor=white)](https://streamlit.io/)
[![MySQL 8.0+](https://img.shields.io/badge/MySQL-8.0+-4479A1.svg?logo=mysql&logoColor=white)](https://www.mysql.com/)
[![Tests](https://img.shields.io/badge/Tests-50%20Passed-brightgreen.svg)]()

An end-to-end industrial analytics and machine learning solution for pre-trip freight cost prediction, route corridor intelligence, and fleet expense optimization across Indian highway networks. Built with **Scikit-Learn**, **Keras/PyTorch**, **SHAP**, **MySQL**, **Power BI**, and **Streamlit**.

> ⚠️ **Synthetic Data Disclosure:** This project utilizes an educational synthetic dataset consisting of approximately 15,000 simulated commercial truck trips across 16 Indian industrial hubs. Target costs are formula-generated. High evaluation metrics (e.g., $R^2 > 0.99$) reflect the mathematical generation formula and should not be quoted as real-world operational performance.

---

## 📋 Table of Contents

- [Executive Summary & Industrial Relevance](#-executive-summary--industrial-relevance)
- [Problem Statement](#-problem-statement)
- [System Architecture](#-system-architecture)
- [Dataset & Data Governance](#-dataset--data-governance)
- [Feature Engineering & Target Leakage Prevention](#-feature-engineering--target-leakage-prevention)
- [Model Benchmark & Evaluation Results](#-model-benchmark--evaluation-results)
- [Model Explainability (SHAP)](#-model-explainability-shap)
- [MySQL Star-Schema Warehouse & Analytics](#-mysql-star-schema-warehouse--analytics)
- [Power BI Executive Dashboard Guide](#-power-bi-executive-dashboard-guide)
- [Streamlit Application Walkthrough](#-streamlit-application-walkthrough)
- [Project Directory Structure](#-project-directory-structure)
- [Installation & Execution Guide](#-installation--execution-guide)
- [Test Suite & Quality Assurance](#-test-suite--quality-assurance)
- [Limitations & Engineering Roadmap](#-limitations--engineering-roadmap)

---

## 🏭 Executive Summary & Industrial Relevance

In long-haul freight operations and industrial logistics engineering, accurate pre-dispatch cost forecasting is critical for:
1. **Dynamic Freight Pricing:** Quoting profitable shipper rates that adjust for route difficulty, diesel volatility, and return-haul demand.
2. **Dispatch & Load Optimization:** Selecting vehicle capacities that maximize payload utilization without incurring unnecessary wear or overloading penalties.
3. **Budgetary Variance Analysis:** Establishing baseline operational expectations to flag high-variance corridors and excessive maintenance expenses.

This project delivers an integrated predictive pipeline and decision-support dashboard tailored for industrial engineering teams managing distributed carrier networks.

---

## 🎯 Problem Statement

A commercial transport fleet needs to predict the operating cost (`actual_trip_cost_inr`) for individual and batch truck dispatches across Indian national and state highway corridors. 

**Core Technical Challenges Addressed:**
- **Preventing Target Leakage:** Ensuring that realized post-trip figures (actual revenue, trip profit, post-trip maintenance spikes) are strictly excluded from pre-dispatch training features.
- **Handling High Cardinality & Route Dynamics:** Integrating continuous mechanical parameters (load weight, fuel efficiency, distance) with discrete categorical variables (origin/destination cities, truck classifications).
- **Explainable Decision Support:** Providing dispatchers and fleet managers with transparent SHAP feature attributions explaining *why* a particular corridor or vehicle configuration escalates operating expense.

---

## 🏗️ System Architecture

```
                                  DATA INGESTION & PIPELINE
                                              │
              ┌───────────────────────────────┴───────────────────────────────┐
              ▼                                                               ▼
    Raw CSV Data (15K Rows)                                        MySQL Relational DW
              │                                                     (Star Schema: Fact/Dims)
              ▼                                                               │
    Schema Validation & Pre-Trip Checks                                       ▼
    (Positive Distances, Valid Load-to-Capacity)                   Power BI Executive Reporting
              │                                                    (Executive / Route / Cost Views)
              ▼
    Feature Engineering (Leakage-Safe)
    - Load Utilization %
    - Estimated Fuel Litres & Fuel Cost
    - Pre-Trip Direct Expense Estimates
              │
              ▼
    Scikit-Learn ColumnTransformer
    - Numerical: StandardScaler
    - Categorical: OneHotEncoder (69 Processed Features)
              │
              ├───────────────────────────────┬───────────────────────────────┐
              ▼                               ▼                               ▼
    Tree-Based Regressors              ANN Regressor               SHAP Attribution Engine
    - HistGradientBoosting (Best)      - 128 -> 64 -> 32 -> 1       - Global Feature Importance
    - Random Forest                    - Dropout (0.2)             - Waterfall Prediction Analysis
    - Linear Regression                - Adam + EarlyStopping
              │                               │                               │
              └───────────────────────────────┼───────────────────────────────┘
                                              ▼
                               Streamlit Operations Intelligence
                               (Single / Batch / Route / Benchmarks)
```

---

## 📊 Dataset & Data Governance

The dataset comprises **15,000 synthetic trip records** across 16 major Indian commercial freight hubs:
* **Origins & Destinations:** Ahmedabad, Bengaluru, Bhopal, Chennai, Delhi, Hyderabad, Indore, Jaipur, Kolkata, Lucknow, Mumbai, Nagpur, Nashik, Pune, Surat, Vadodara.
* **Vehicle Classes:** Heavy (16t typical capacity), Medium (9t), Light Commercial Vehicle / LCV (3.5t), Multi-Axle Trailer (25t).
* **Cost Variables:** Distance (km), Diesel Price (₹/L), Tolls, Driver Allowance, Maintenance, Loading/Unloading, Miscellaneous Costs, Route Multiplier, Traffic Factor, Dispatch Month.

### Data Validation Checks:
- Distance $> 0$, Truck Capacity $> 0$, Load Weight $\ge 0$.
- Business Constraint Check: $\text{Payload Weight} \le \text{Vehicle Rated Capacity}$.
- Category Check: Truck classification strictly validated against approved vehicle schemas.
- Outlier Monitoring: IQR bounds computed for distance, load, and unit fuel consumption.

---

## ⚙️ Feature Engineering & Target Leakage Prevention

### 1. Strict Feature Classification Matrix
| Feature Category | Features Included | Allowed in Model Input? |
| :--- | :--- | :---: |
| **Pre-Trip Features** | `distance_km`, `truck_type`, `truck_capacity_tons`, `load_weight_tons`, `fuel_efficiency_km_per_litre`, `diesel_price_inr_per_litre`, `toll_cost_inr`, `driver_allowance_inr`, `maintenance_cost_inr`, `loading_unloading_cost_inr`, `other_cost_inr`, `route_factor`, `traffic_factor`, `month`, cities & states | **YES** |
| **Pre-Trip Engineered** | `load_utilization_pct`, `estimated_fuel_litres`, `estimated_fuel_cost_inr`, `estimated_direct_expenses_inr`, `cost_per_ton_km_estimate` | **YES** |
| **Post-Trip Realized** | `actual_trip_cost_inr` (Target), `freight_revenue_inr`, `trip_profit_inr`, `actual_cost_per_km`, `profit_margin_pct` | **NO (STRICT LEAKAGE)** |

### 2. Engineered Pre-Trip Formulations:
- **Load Utilization Percentage:**
  $$\text{Load Utilization \%} = \left(\frac{\text{Payload Weight (tons)}}{\text{Truck Capacity (tons)}}\right) \times 100$$
- **Estimated Pre-Trip Fuel Cost:**
  $$\text{Est. Fuel Cost (₹)} = \left(\frac{\text{Distance (km)}}{\text{Fuel Efficiency (km/L)}}\right) \times \text{Diesel Price (₹/L)}$$
- **Total Estimated Direct Expenses:**
  $$\text{Direct Expenses} = \text{Est. Fuel Cost} + \text{Tolls} + \text{Driver Allowance} + \text{Budgeted Maintenance} + \text{Handling} + \text{Other}$$

---

## 📈 Model Benchmark & Evaluation Results

All candidate regressors were evaluated on an identical **held-out test set (3,000 samples, 20% split, random seed = 42)** following training-only preprocessing fitting:

| Model Architecture | Test MAE (₹) | Test RMSE (₹) | Test $R^2$ Score | 3-Fold CV MAE (₹) | Model Selection Status |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Dummy Baseline (Mean)** | ₹16,170 | ₹19,688 | -0.0040 | — | Reference Baseline |
| **Linear Regression** | ₹3,635 | ₹4,993 | 0.9354 | ₹3,786 ± 74 | Parametric Baseline |
| **Random Forest Regressor** | ₹1,927 | ₹2,620 | 0.9822 | ₹2,147 ± 41 | Non-Linear Baseline |
| **Artificial Neural Network (Keras)** | ₹1,298 | ₹1,722 | 0.9923 | — | Deep Learning Candidate |
| **HistGradientBoosting Regressor** | **₹746** | **₹1,028** | **0.9973** | **₹880 ± 8** | **Selected Production Model** |

> **Model Selection Rationale:** In accordance with industrial operations best practices, **HistGradientBoostingRegressor** was selected as the primary production model because it achieved the **lowest Mean Absolute Error (₹746)** and lowest cross-validation variance, outperforming the ANN while running with faster inference latency and full native SHAP TreeExplainer support.

### Error Analysis by Fleet Category (Best Model):
- **LCV (3.5t):** MAE = ₹631 | RMSE = ₹833 ($R^2 = 0.9951$)
- **Medium (9.0t):** MAE = ₹631 | RMSE = ₹870 ($R^2 = 0.9968$)
- **Heavy (16.0t):** MAE = ₹772 | RMSE = ₹1,029 ($R^2 = 0.9972$)
- **Trailer (25.0t):** MAE = ₹949 | RMSE = ₹1,343 ($R^2 = 0.9969$)

---

## 🔬 Model Explainability (SHAP)

To prevent "black box" deployment risks, the system implements **SHAP (SHapley Additive exPlanations)** in `src/explainability.py`:

1. **Global Feature Importance:**
   - Evaluates the mean absolute Shapley values across the fleet. Distance, maintenance estimates, fuel efficiency, and traffic condition multipliers emerge as the primary drivers of cost variance.
2. **Individual Prediction Waterfall Explanations:**
   - Every single-trip prediction in the Streamlit app generates an individual SHAP attribution breakdown highlighting which factors elevated (red) or lowered (green) the cost relative to the baseline expectation.
3. **Causal Disclaimer:**
   - SHAP values quantify empirical model dependencies and statistical correlations within this synthetic dataset; they do not constitute mathematical proof of physical causality.

---

## 🗄️ MySQL Star-Schema Warehouse & Analytics

A modular relational data warehouse was engineered in `sql/` to model fleet operations:

### 1. Schema Design
- `dim_truck_type`: Dimensions for the 4 truck categories and standard rated capacities.
- `dim_route`: Unique origin-destination corridor dimension with geographic attributes.
- `fact_trip_cost`: Core transactional fact table indexed on `route_id`, `truck_type_id`, and `trip_month`.
*(Note: A calendar dimension table was intentionally omitted because the dataset contains single-integer month numbers rather than continuous timestamps).*

### 2. Advanced Analytical Queries (`sql/03_logistics_analysis.sql`):
- **Window Functions:** Ranking trip efficiencies within truck classes using `RANK()` and `DENSE_RANK()`.
- **Corridor CTEs:** Common Table Expressions identifying routes exceeding regional cost averages.
- **Weighted Cost per KM:** Calculated via $\frac{\sum(\text{Cost} \times \text{Distance})}{\sum(\text{Distance})}$.
- **Rolling Averages:** 3-month rolling cost moving average using `ROWS BETWEEN 2 PRECEDING AND CURRENT ROW`.
- **Load Utilization Bands:** `CASE WHEN` segmentation into Under-loaded (<50%), Moderate (50-75%), Well-loaded (75-90%), and Full (>90%).

---

## 📊 Power BI Executive Dashboard Guide

The project includes production-ready Power BI documentation in `powerbi/`:

### 1. Data Model & Relationships
- Star-schema links: `fact_trip_cost[route_id]` $\rightarrow$ `dim_route[route_id]` (Many-to-One, Single cross-filter).
- `fact_trip_cost[truck_type_id]` $\rightarrow$ `dim_truck_type[truck_type_id]` (Many-to-One).

### 2. Comprehensive DAX Measures Library (`powerbi/measures.md`)
Includes 18 documented DAX measures for:
- `Total Trips`, `Total Cost`, `Cost per KM`, `Average Load Utilization %`
- `Profit Margin %`, `Profitable Trips %`
- `Weighted Avg Cost per KM`
- Expense component breakdowns (Toll, Fuel, Driver Allowance, Maintenance)

### 3. Three Executive Report Views (`powerbi/dashboard_guide.md`):
1. **Executive Logistics Overview:** High-level KPIs, monthly trend lines, fleet volume distributions.
2. **Route and Vehicle Efficiency:** Corridor matrices, distance vs. cost scatter visuals, top 10 expensive routes.
3. **Operational Cost Analysis:** Expense category stacked bars, utilization histograms, margin diagnostics.

---

## 💻 Streamlit Application Walkthrough

The Streamlit dashboard (`app.py`) provides an interactive interface featuring:
1. **Operations Overview:** Real-time KPI summary cards, cost distributions, and monthly fleet trends.
2. **AI Cost Prediction:** Single-trip parameter configuration, dynamic payload-to-capacity validation, immediate cost predictions, and live SHAP waterfall attributions.
3. **Batch Prediction (CSV):** Drag-and-drop CSV batch evaluation with schema validation, summary metric aggregations, and one-click prediction download.
4. **Route Intelligence:** Corridors sorted by cost intensity with interactive scatter plotting.
5. **Expense & Load Analysis:** Categorical expense share analysis and capacity utilization bands.
6. **Model Benchmarks & SHAP:** Multi-model comparative metrics table, residual diagnostic images, and global feature importance charts.

---

## 📂 Project Directory Structure

```
indian-truck-cost-prediction/
│
├── data/
│   ├── indian_truck_logistics_synthetic_15000.csv  # Raw dataset (15,000 records)
│   └── processed_logistics_data.csv               # Engineered dataset
│
├── models/                                         # Generated model artifacts
│   ├── hgbr_model.pkl                             # Best Model (HistGradientBoosting)
│   ├── truck_cost_ann.keras                       # Keras/PyTorch ANN model
│   ├── rf_model.pkl                               # Random Forest Regressor
│   ├── baseline_lr.pkl                            # Baseline Linear Regression
│   ├── preprocessor.pkl                           # Fitted ColumnTransformer
│   ├── feature_schema.json                        # Feature metadata & column schemas
│   ├── evaluation_metrics.json                    # Formal benchmark metrics & error analysis
│   ├── model_comparison.png                       # Comparative metric visual
│   ├── actual_vs_predicted.png                    # Residual analysis visual
│   └── training_history.png                       # ANN training & validation loss curves
│
├── notebooks/
│   └── truck_cost_prediction.ipynb                # Exploratory analysis notebook
│
├── powerbi/
│   ├── dashboard_guide.md                         # Architecture, layout, and visual guide
│   └── measures.md                                # DAX formula library
│
├── sql/
│   ├── 01_create_database.sql                     # Database & charset initialization
│   ├── 02_create_tables.sql                       # Star-schema table definitions & constraints
│   ├── 03_logistics_analysis.sql                  # 13 advanced analytical SQL queries
│   └── 04_load_data.sql                           # Data loading & ingestion templates
│
├── src/
│   ├── __init__.py
│   ├── data_utils.py                              # Loading, schema validation, preprocessor
│   ├── feature_engineering.py                     # Leakage-safe features & quality reports
│   ├── train_model.py                             # Multi-model training & evaluation pipeline
│   ├── prediction.py                              # Single & batch inference routines
│   ├── explainability.py                          # SHAP tree-attribution & waterfall plots
│   ├── database.py                                # MySQL connection & warehouse loading
│   └── analytics.py                               # Aggregations, KPIs, and route analytics
│
├── tests/
│   ├── __init__.py
│   ├── test_data_utils.py                         # Loading & preprocessing unit tests
│   ├── test_feature_engineering.py                # Quality checks & leakage prevention tests
│   ├── test_prediction.py                         # Single & batch inference tests
│   └── test_explainability.py                     # SHAP attribution tests
│
├── .env.example                                   # Environment variable template
├── .gitignore                                     # Git ignore rules
├── app.py                                         # Upgraded Streamlit operations dashboard
├── LICENSE                                        # MIT License
├── README.md                                      # Project documentation
└── requirements.txt                               # Project dependencies
```

---

## 🚀 Installation & Execution Guide

### 1. Prerequisites & Environment Setup
Clone the repository and install dependencies:
```bash
git clone https://github.com/pawano6/indian-truck-cost-prediction.git
cd indian-truck-cost-prediction

python -m venv .venv
# Windows:
.\.venv\Scripts\activate
# Linux/macOS:
source .venv/bin/activate

pip install -r requirements.txt
```

### 2. Configure Environment Variables
Copy the `.env.example` file to `.env`:
```bash
cp .env.example .env
```
*(Optionally provide MySQL credentials if testing database integration)*.

### 3. Execute Model Training & Benchmarking
Run the end-to-end model training pipeline:
```bash
python -m src.train_model
```
This trains all 5 regressors, fits the preprocessing pipeline, performs residual analysis, generates diagnostic plots, and saves all artifacts to `models/`.

### 4. Run the Full Test Suite
```bash
python -m pytest tests/ -v
```

### 5. Launch the Streamlit Intelligence Dashboard
```bash
streamlit run app.py
```

---

## 🧪 Test Suite & Quality Assurance

The project includes **50 automated unit tests** covering all critical components:
- `tests/test_data_utils.py` (26 tests): Validates column schemas, negative value checks, preprocessing transformations, and unknown categorical value handling.
- `tests/test_feature_engineering.py` (11 tests): Verifies load utilization math, fuel calculations, operational metrics, and strict target leakage prevention.
- `tests/test_prediction.py` (9 tests): Tests single-trip inference, batch CSV inference, and boundary input validation (negative distances, overloaded vehicles, out-of-range months).
- `tests/test_explainability.py` (4 tests): Tests SHAP TreeExplainer generation, global feature importance ranking, and prediction waterfall attribution.

**Execution Result:**
```
======================= 50 passed in 13.89s =======================
```

---

## ⚠️ Limitations & Engineering Roadmap

1. **Synthetic Nature of Target Labels:**
   - Because the target variable `actual_trip_cost_inr` was generated using a deterministic formula with simulated noise, $R^2$ scores across advanced tree models and neural networks exceed 0.99. In real-world freight environments, stochastic delays, fuel theft, driver negotiations, and weather disruptions typically cap $R^2$ between 0.75 and 0.88.
2. **Date Granularity:**
   - The dataset provides monthly integers (1–12) rather than timestamps. Future iterations should incorporate day-of-week, holiday seasonality, and real-time toll revisions.
3. **External Real-Time APIs:**
   - Incorporating live GPS telematics and OpenStreetMap routing APIs would enhance highway toll calculation precision over synthetic route multipliers.

---

## 📜 License

This project is licensed under the MIT License — see the [LICENSE](LICENSE) file for details.
